package com.psii.app_adapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
